#!/bin/bash
echo "🚀 Setting up Supermarket Scraper..."

mkdir -p data logs
pip install -r requirements.txt

if [ ! -f .env ]; then
    cp .env.example .env
    echo "📝 Created .env - edit with your webhook URL"
fi

chmod +x scripts/*.sh
echo "✅ Setup complete! Run: python src/simple_scraper.py"