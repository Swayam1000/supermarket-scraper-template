# Dutch Supermarket Scraper Template

🚀 **One-click supermarket scraper for Dutch stores with Grocerlyze integration**

[![Use this template](https://img.shields.io/badge/Use%20this-Template-blue?style=for-the-badge)](https://github.com/yourusername/supermarket-scraper-template/generate)

## ✨ Features

- 🏪 Scrapes 5 major Dutch supermarkets (Dirk, Albert Heijn, Jumbo, PLUS, Lidl)
- 🔄 Auto-translation Dutch → English
- 📱 Grocerlyze app integration via webhook
- 🐳 Docker deployment ready
- 📊 SQLite database with deal tracking
- ⏰ Scheduled scraping (3x per week)